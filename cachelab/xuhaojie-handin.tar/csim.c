#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
       #include <getopt.h>

#include "cachelab.h"

int s,b,e;



void print_usage(void)
{
    printf(""
    "-h: Optional help flag that prints usage info\n"
    "-v: Optional verbose flag that displays trace info\n"
    "-s <s>: Number of set index bits (S = 2s is the number of sets)\n"
    "-E <E>: Associativity (number of lines per set)\n"
    "-b <b>: Number of block bits (B = 2b is the block size)\n "
    "-t <tracefile>: Name of the valgrind trace to replay\n");
}

void parse_file(FILE* fd)
{

}

int main(int argc, char* argv[])
{
    int ch;
    FILE* fd;
    while ((ch = getopt(argc, argv, "hv:s:E:b:")) != -1)
    {
        switch(ch)
        {
        case 'h':
        {
            print_usage();
            break;
        }
        case 'v':
        {
            //display_trace();
            break;
        }
        case 's':
        {
            s = atoi(optarg);
            break;
        }
        case 'E':
        {   
            s = atoi(optarg);
            break;
        }
        case 'b':
        {
            s = atoi(optarg);
            break;
        }
        case 't':
        {
            fd = fopen(optarg,"rb");
        }
        }
    }

    parse_file(fd); 
    printSummary(0, 0, 0);
    return 0;
}
